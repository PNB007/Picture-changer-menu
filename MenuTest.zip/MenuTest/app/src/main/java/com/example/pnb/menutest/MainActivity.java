package com.example.pnb.menutest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public Integer images[] = {R.drawable.btnred, R.drawable.btnyellow, R.drawable.btnpurple, R.drawable.btnblue};
    public int currImage = 3;
    ImageView image;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        image = (ImageView) findViewById(R.id.img);
        // initial image
        image.setImageResource(images[currImage]);

        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //Creating the instance of PopupMenu
                PopupMenu popup = new PopupMenu(MainActivity.this, button);
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate(R.menu.popup_menu, popup.getMenu());

                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.one:
                                currImage = 0;
                                break;
                            case R.id.two:
                                currImage = 1;
                                break;
                            case R.id.three:
                                currImage = 2;
                                break;
                            case R.id.four:
                                currImage = 3;
                                break;
                        }
                        image.setImageResource(images[currImage]);
                        //Toast.makeText(MainActivity.this,"Selected: '" + item.getTitle() + "' ID: "+ currImage, Toast.LENGTH_SHORT).show();
                        return true;
                    }
                });
                popup.show();//showing popup menu
            }
        });
    }
}